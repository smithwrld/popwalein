import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { clients } from '@/data/clients';
import { TermsCondition } from '@/lib/quotationApi';

interface PdfPayload {
  quotationNumber: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  projectLocation: string;
  projectType: string;
  areaSqft: string;
  description: string;
  serviceName: string;
  selections: { parameterName: string; productName: string }[];
  dateString?: string;
}

/**
 * Utility to generate a high-quality 3-page PDF quotation
 */
export async function generateQuotationPdf(
  payload: PdfPayload,
  terms: TermsCondition[]
): Promise<void> {
  const dateString = payload.dateString || new Date().toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  // Create temporary container
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '-9999px';
  container.style.width = '800px';
  container.style.backgroundColor = '#f3f4f6';

  // Common Header Template HTML
  const getHeaderHtml = (pageNumber: number) => `
    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #e5e7eb; padding-bottom: 15px; margin-bottom: 25px;">
      <div>
        <h1 style="font-size: 28px; font-weight: 400; color: #2b5a5e; margin: 0; letter-spacing: -0.03em; font-family: 'Neue Haas', sans-serif;">Popwale</h1>
        <p style="font-size: 10px; color: #6b7280; margin: 2px 0 0 0; letter-spacing: 0.05em; text-transform: uppercase; font-family: 'Neue Haas', sans-serif; font-weight: 300;">Premium Ceiling & Interior Solutions</p>
      </div>
      <div style="text-align: right; font-family: 'Neue Haas', sans-serif;">
        <p style="font-size: 11px; font-weight: 400; color: #1f2937; margin: 0;">Quotation ref: <strong>#${payload.quotationNumber}</strong></p>
        <p style="font-size: 10px; color: #6b7280; margin: 2px 0 0 0;">Date: ${dateString}</p>
      </div>
    </div>
  `;

  // Common Footer Template HTML
  const getFooterHtml = (pageNumber: number) => `
    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #e5e7eb; padding-top: 15px; font-size: 9px; color: #9ca3af; font-family: 'Neue Haas', sans-serif;">
      <div>
        <span>📍 Rajkot, Gujarat, India</span>
        <span style="margin: 0 8px;">|</span>
        <span>📞 +91 99090 94033</span>
        <span style="margin: 0 8px;">|</span>
        <span>📧 contact@popwale.in</span>
      </div>
      <div style="font-weight: 400;">Page ${pageNumber} of 3</div>
    </div>
  `;

  // Helper to create page container with A4 aspect ratio (800px x 1130px)
  const createPageWrapper = () => {
    const page = document.createElement('div');
    page.style.width = '800px';
    page.style.height = '1130px';
    page.style.padding = '55px';
    page.style.boxSizing = 'border-box';
    page.style.backgroundColor = '#ffffff';
    page.style.display = 'flex';
    page.style.flexDirection = 'column';
    page.style.justifyContent = 'space-between';
    page.style.position = 'relative';
    return page;
  };

  // --------------------------------------------------
  // PAGE 1: Customer Selections & Project Details
  // --------------------------------------------------
  const page1 = createPageWrapper();
  page1.innerHTML = `
    ${getHeaderHtml(1)}
    <div style="flex-grow: 1; display: flex; flex-direction: column; justify-content: flex-start; gap: 20px; font-family: 'Neue Haas', sans-serif;">
      <div>
        <h2 style="font-size: 15px; font-weight: 400; color: #2b5a5e; margin: 0 0 10px 0; border-bottom: 2px solid #2b5a5e; padding-bottom: 4px; display: inline-block; text-transform: uppercase; letter-spacing: 0.05em;">Client & Site Details</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; font-size: 12px; line-height: 1.5; color: #374151;">
          <div>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Customer Name:</span> <span style="font-weight: 400; color: #111827;">${payload.customerName}</span></p>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Phone Number:</span> <span style="font-weight: 400; color: #111827;">${payload.customerPhone}</span></p>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Email Address:</span> <span style="font-weight: 400; color: #111827;">${payload.customerEmail || '—'}</span></p>
          </div>
          <div>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Project Location:</span> <span style="font-weight: 400; color: #111827;">${payload.projectLocation}</span></p>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Space Type:</span> <span style="font-weight: 400; color: #111827; text-transform: capitalize;">${payload.projectType || '—'}</span></p>
            <p style="margin: 3px 0;"><span style="color: #6b7280; font-weight: 300;">Total Area:</span> <span style="font-weight: 400; color: #111827;">${payload.areaSqft ? `${payload.areaSqft} sq.ft` : '—'}</span></p>
          </div>
        </div>
      </div>
      
      <div>
        <h2 style="font-size: 15px; font-weight: 400; color: #2b5a5e; margin: 0 0 8px 0; border-bottom: 2px solid #2b5a5e; padding-bottom: 4px; display: inline-block; text-transform: uppercase; letter-spacing: 0.05em;">Selected Service</h2>
        <p style="font-size: 14px; font-weight: 400; color: #111827; margin: 2px 0 0 0;">${payload.serviceName}</p>
      </div>

      <div style="flex-grow: 1; display: flex; flex-direction: column;">
        <h2 style="font-size: 15px; font-weight: 400; color: #2b5a5e; margin: 0 0 10px 0; border-bottom: 2px solid #2b5a5e; padding-bottom: 4px; display: inline-block; text-transform: uppercase; letter-spacing: 0.05em;">Material Specifications</h2>
        <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: left; margin-top: 5px;">
          <thead>
            <tr style="background-color: #f9fafb; border-bottom: 1px solid #e5e7eb;">
              <th style="padding: 8px 12px; font-weight: 400; color: #4b5563; width: 45%;">Scope / Category</th>
              <th style="padding: 8px 12px; font-weight: 400; color: #4b5563; width: 55%;">Selected Specification</th>
            </tr>
          </thead>
          <tbody>
            ${payload.selections.map((sel, idx) => `
              <tr style="border-bottom: 1px solid #f3f4f6; background-color: ${idx % 2 === 0 ? '#ffffff' : '#fafafa'};">
                <td style="padding: 8px 12px; color: #4b5563; font-weight: 300;">${sel.parameterName}</td>
                <td style="padding: 8px 12px; color: #111827; font-weight: 400;">${sel.productName}</td>
              </tr>
            `).join('')}
            ${payload.selections.length === 0 ? `
              <tr>
                <td colspan="2" style="padding: 20px; text-align: center; color: #9ca3af; font-style: italic;">Standard Inclusions & Specifications</td>
              </tr>
            ` : ''}
          </tbody>
        </table>
      </div>

      ${payload.description ? `
        <div style="background-color: #fafafa; border-left: 3px solid #2b5a5e; padding: 12px 15px; font-size: 11px; border-radius: 4px;">
          <span style="font-weight: 400; color: #4b5563; display: block; margin-bottom: 4px; text-transform: uppercase; font-size: 10px; letter-spacing: 0.03em;">Client Notes / Context:</span>
          <span style="color: #1f2937; font-weight: 300; line-height: 1.4; display: block;">${payload.description}</span>
        </div>
      ` : ''}
    </div>
    ${getFooterHtml(1)}
  `;

  // --------------------------------------------------
  // PAGE 2: Client List Grid
  // --------------------------------------------------
  const page2 = createPageWrapper();
  page2.innerHTML = `
    ${getHeaderHtml(2)}
    <div style="flex-grow: 1; display: flex; flex-direction: column; justify-content: flex-start; gap: 15px; font-family: 'Neue Haas', sans-serif;">
      <div style="text-align: center; margin-bottom: 10px;">
        <h2 style="font-size: 20px; font-weight: 400; color: #2b5a5e; margin: 0 0 6px 0; letter-spacing: -0.02em; text-transform: uppercase; font-size: 16px; letter-spacing: 0.05em;">Our Esteemed Clients</h2>
        <p style="font-size: 11px; color: #6b7280; margin: 0 auto; max-width: 500px; font-weight: 300; line-height: 1.4;">
          We have successfully delivered quality false ceiling, gypsum partitions, and plastering solutions for premium commercial projects, corporate environments, and leading local brands.
        </p>
      </div>
      
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 10px; width: 100%;">
        ${clients.slice(0, 16).map(client => `
          <div style="border: 1px solid #f3f4f6; border-radius: 12px; padding: 10px; background-color: #ffffff; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 110px; box-sizing: border-box; text-align: center;">
            <div style="height: 55px; display: flex; align-items: center; justify-content: center; margin-bottom: 6px; width: 100%;">
              ${client.logo ? `
                <img src="${client.logo}" alt="${client.name}" style="max-height: 100%; max-width: 100%; object-fit: contain;" />
              ` : `
                <div style="width: 40px; height: 40px; border-radius: 50%; background-color: #f3f4f6; color: #2b5a5e; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 400;">
                  ${client.name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()}
                </div>
              `}
            </div>
            <span style="font-size: 9px; font-weight: 400; color: #374151; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width: 100%; display: block;">${client.name}</span>
            <span style="font-size: 8px; color: #9ca3af; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; width: 100%; font-weight: 300; display: block; margin-top: 1px;">${client.type}</span>
          </div>
        `).join('')}
      </div>
    </div>
    ${getFooterHtml(2)}
  `;

  // --------------------------------------------------
  // PAGE 3: Terms & Conditions & Sign-off
  // --------------------------------------------------
  const page3 = createPageWrapper();
  page3.innerHTML = `
    ${getHeaderHtml(3)}
    <div style="flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; gap: 20px; font-family: 'Neue Haas', sans-serif;">
      <div>
        <h2 style="font-size: 15px; font-weight: 400; color: #2b5a5e; margin: 0 0 15px 0; border-bottom: 2px solid #2b5a5e; padding-bottom: 4px; display: inline-block; text-transform: uppercase; letter-spacing: 0.05em;">Terms & General Conditions</h2>
        <ul style="padding-left: 18px; font-size: 11px; line-height: 1.8; color: #374151; margin: 0; font-weight: 300;">
          ${terms.map(t => `
            <li style="margin-bottom: 12px; padding-left: 4px;">
              <span style="font-weight: 400; color: #1f2937;">${t.bullet_point}</span>
            </li>
          `).join('')}
        </ul>
      </div>
      
      <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-top: 40px; padding-top: 20px;">
        <div style="font-size: 10px; color: #6b7280; line-height: 1.4;">
          <p style="margin: 0; font-weight: 400; color: #4b5563; text-transform: uppercase; font-size: 9px; letter-spacing: 0.02em;">Prepared By:</p>
          <p style="margin: 20px 0 0 0; font-weight: 400; font-size: 12px; color: #111827;">Popwale Ceiling Contractors</p>
          <p style="margin: 2px 0 0 0; font-weight: 300;">Rajkot Office Estimation Unit</p>
        </div>
        
        <div style="text-align: right; font-size: 10px; color: #6b7280; line-height: 1.4;">
          <p style="margin: 0; font-weight: 400; color: #4b5563; text-transform: uppercase; font-size: 9px; letter-spacing: 0.02em;">Client Authorization:</p>
          <div style="width: 160px; border-bottom: 1px dashed #d1d5db; height: 35px; margin-left: auto;"></div>
          <p style="margin: 6px 0 0 0; font-weight: 300;">Authorized Signature & Seal</p>
        </div>
      </div>
    </div>
    ${getFooterHtml(3)}
  `;

  // Append pages to container
  container.appendChild(page1);
  container.appendChild(page2);
  container.appendChild(page3);
  document.body.appendChild(container);

  try {
    // Generate canvas images sequentially to prevent load spikes
    const options = {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    };

    const canvas1 = await html2canvas(page1, options);
    const canvas2 = await html2canvas(page2, options);
    const canvas3 = await html2canvas(page3, options);

    // Assemble PDF
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'px',
      format: [800, 1130]
    });

    const img1 = canvas1.toDataURL('image/jpeg', 0.95);
    pdf.addImage(img1, 'JPEG', 0, 0, 800, 1130);

    pdf.addPage([800, 1130]);
    const img2 = canvas2.toDataURL('image/jpeg', 0.95);
    pdf.addImage(img2, 'JPEG', 0, 0, 800, 1130);

    pdf.addPage([800, 1130]);
    const img3 = canvas3.toDataURL('image/jpeg', 0.95);
    pdf.addImage(img3, 'JPEG', 0, 0, 800, 1130);

    // Save
    pdf.save(`Popwale_Quotation_${payload.quotationNumber}.pdf`);
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw new Error('PDF compilation failed. Please try again.');
  } finally {
    // Clean up temporary DOM nodes
    if (container.parentNode) {
      container.parentNode.removeChild(container);
    }
  }
}
