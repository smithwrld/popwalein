import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { ProjectDetailsData } from './StepProjectDetails';
import { QuotationService, ServiceParameter, getTermsConditions } from '@/lib/quotationApi';
import {
  User,
  Layers,
  CheckCircle2,
  Edit2,
  Send,
  Loader2,
  Sparkles,
  MessageCircle,
  Copy,
  FileText,
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { generateQuotationPdf } from '@/lib/pdfGenerator';

interface SelectedProductDetail {
  parameterId: string;
  parameterName: string;
  productId: string;
  productName: string;
  productDescription?: string | null;
}

interface StepReviewSubmitProps {
  projectDetails: ProjectDetailsData;
  service: QuotationService | null;
  parameters: ServiceParameter[];
  selectedProducts: Record<string, string>; // parameterId -> productId
  onEditStep: (stepIndex: number) => void;
  onSubmitQuotation: () => void;
  isSubmitting: boolean;
  submissionResult: {
    success: boolean;
    quotationNumber: string;
    whatsappUrl?: string;
  } | null;
  onReset: () => void;
}

export const StepReviewSubmit: React.FC<StepReviewSubmitProps> = ({
  projectDetails,
  service,
  parameters,
  selectedProducts,
  onEditStep,
  onSubmitQuotation,
  isSubmitting,
  submissionResult,
  onReset,
}) => {
  const { toast } = useToast();
  const [pdfGenerating, setPdfGenerating] = useState(false);

  const handleDownloadPdf = async () => {
    if (!submissionResult) return;
    setPdfGenerating(true);
    try {
      const terms = await getTermsConditions();
      await generateQuotationPdf({
        quotationNumber: submissionResult.quotationNumber,
        customerName: projectDetails.name,
        customerPhone: projectDetails.phone,
        customerEmail: projectDetails.email,
        projectLocation: projectDetails.location,
        projectType: projectDetails.projectType,
        areaSqft: projectDetails.area,
        description: projectDetails.description,
        serviceName: service?.name || 'Ceiling & Plaster Solutions',
        selections: requirementsList.map((req) => ({
          parameterName: req.parameterName,
          productName: req.productName
        }))
      }, terms);
      
      toast({
        title: 'PDF Downloaded',
        description: `Quotation PDF #${submissionResult.quotationNumber} exported successfully.`,
      });
    } catch (err: any) {
      console.error('Failed to generate PDF:', err);
      toast({
        title: 'Error generating PDF',
        description: err.message || 'Could not compile PDF quotation.',
        variant: 'destructive',
      });
    } finally {
      setPdfGenerating(false);
    }
  };

  // Extract selected product details
  const requirementsList: SelectedProductDetail[] = parameters
    .filter((param) => selectedProducts[param.id])
    .map((param) => {
      const prodId = selectedProducts[param.id];
      const prod = param.products?.find((p) => p.id === prodId);
      return {
        parameterId: param.id,
        parameterName: param.name,
        productId: prodId,
        productName: prod?.name || 'Selected Option',
        productDescription: prod?.description || null,
      };
    });

  if (submissionResult && submissionResult.success) {
    return (
      <div className="text-center py-8 px-4 sm:px-8 bg-card rounded-[28px] border-2 border-primary/20 shadow-xl shadow-primary/5 animate-scale-in max-w-2xl mx-auto space-y-5">
        <div className="w-14 h-14 rounded-full bg-primary/10 text-primary flex items-center justify-center mx-auto shadow-inner">
          <Sparkles className="w-7 h-7" />
        </div>

        <div className="space-y-1.5">
          <span className="text-xs font-bold text-primary bg-primary/10 px-3 py-1 rounded-full">
            Quotation Submitted Successfully
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
            Thank You, {projectDetails.name}!
          </h2>
          <p className="text-muted-foreground text-xs sm:text-sm max-w-md mx-auto">
            Your quotation request has been recorded with reference number:
          </p>
        </div>

        {/* Quotation Number Pill */}
        <div className="inline-flex items-center gap-3 bg-muted/60 px-5 py-2.5 rounded-full border border-border">
          <span className="font-mono text-base sm:text-lg font-bold text-foreground tracking-wider">
            {submissionResult.quotationNumber}
          </span>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full text-muted-foreground hover:text-foreground"
            onClick={() => {
              navigator.clipboard.writeText(submissionResult.quotationNumber);
              toast({
                title: 'Copied to clipboard',
                description: `Quotation #${submissionResult.quotationNumber} copied!`,
              });
            }}
          >
            <Copy className="w-3.5 h-3.5" />
          </Button>
        </div>

        <div className="p-4 bg-primary/5 border border-primary/15 rounded-[20px] text-left text-xs sm:text-sm space-y-2">
          <p className="font-semibold text-foreground flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-primary" />
            What happens next:
          </p>
          <ul className="list-disc list-inside text-muted-foreground space-y-1 pl-1 text-xs">
            <li>Our Rajkot technical estimator will review your exact material selections.</li>
            <li>You will receive a line-item estimate & rate breakdown within 24 hours.</li>
            <li>Free site measurement & physical sample showcase available on request.</li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
          {submissionResult.whatsappUrl && (
            <Button
              className="btn-hero rounded-full flex items-center justify-center gap-2 text-sm py-4 px-6"
              onClick={() => window.open(submissionResult.whatsappUrl, '_blank')}
            >
              <MessageCircle className="w-4 h-4 fill-current" />
              Chat on WhatsApp Directly
            </Button>
          )}

          <Button
            className="rounded-full bg-primary-muted hover:bg-primary-muted/80 text-primary border border-primary/20 flex items-center justify-center gap-2 text-sm py-4 px-6 font-semibold"
            onClick={handleDownloadPdf}
            disabled={pdfGenerating}
          >
            {pdfGenerating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <FileText className="w-4 h-4" />
            )}
            Download PDF Quotation
          </Button>

          <Button
            variant="outline"
            className="rounded-full border-border hover:bg-muted py-4 px-6 text-sm font-semibold"
            onClick={onReset}
          >
            Create Another Quote
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 animate-fade-up">
      <div className="text-left mb-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
          Review Your Quotation
        </h2>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Please verify your project details and specifications before final submission.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {/* Customer Details Card */}
        <div className="bg-card rounded-[28px] p-5 sm:p-6 border border-border/80 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 mb-3.5 border-b border-border/50">
            <h3 className="text-sm sm:text-base font-bold text-foreground flex items-center gap-2">
              <User className="w-4 h-4 text-primary" />
              Project & Contact Information
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEditStep(0)}
              className="h-7 text-xs text-primary hover:text-primary hover:bg-primary/10 rounded-full gap-1 font-semibold px-3"
            >
              <Edit2 className="w-3 h-3" />
              Edit
            </Button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs sm:text-sm">
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Customer Name</span>
              <span className="font-semibold text-foreground">{projectDetails.name || '—'}</span>
            </div>
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Email Address</span>
              <span className="font-semibold text-foreground truncate block">{projectDetails.email || '—'}</span>
            </div>
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Phone Number</span>
              <span className="font-semibold text-foreground">{projectDetails.phone || '—'}</span>
            </div>
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Project Location</span>
              <span className="font-semibold text-foreground">{projectDetails.location || '—'}</span>
            </div>
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Space Type</span>
              <span className="font-semibold text-foreground capitalize">{projectDetails.projectType || 'Not specified'}</span>
            </div>
            <div className="p-3 bg-muted/25 rounded-[20px] border border-border/40">
              <span className="text-[11px] text-muted-foreground block">Estimated Area</span>
              <span className="font-semibold text-foreground">{projectDetails.area ? `${projectDetails.area} sq.ft` : 'Not specified'}</span>
            </div>
          </div>

          {projectDetails.description && (
            <div className="mt-3 pt-2.5 border-t border-border/40 text-xs text-muted-foreground">
              <span className="font-semibold text-foreground block mb-0.5">Notes:</span>
              <p className="italic">{projectDetails.description}</p>
            </div>
          )}
        </div>

        {/* Selected Service Card */}
        <div className="bg-card rounded-[28px] p-5 sm:p-6 border border-border/80 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 mb-3.5 border-b border-border/50">
            <h3 className="text-sm sm:text-base font-bold text-foreground flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" />
              Selected Service
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEditStep(1)}
              className="h-7 text-xs text-primary hover:text-primary hover:bg-primary/10 rounded-full gap-1 font-semibold px-3"
            >
              <Edit2 className="w-3 h-3" />
              Edit
            </Button>
          </div>

          <div className="p-4 rounded-[20px] bg-muted/30 border border-border/50 flex items-center gap-4">
            {service?.image && (
              <img
                src={service.image}
                alt={service.name}
                className="w-16 h-16 rounded-[14px] object-cover border border-border shrink-0"
              />
            )}
            <div>
              <span className="text-[11px] font-semibold text-primary block mb-0.5">
                Primary Service
              </span>
              <h4 className="text-base sm:text-lg font-bold text-foreground">{service?.name || '—'}</h4>
              {service?.description && (
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{service.description}</p>
              )}
            </div>
          </div>
        </div>

        {/* Component Specifications Card */}
        <div className="bg-card rounded-[28px] p-5 sm:p-6 border border-border/80 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between pb-3 mb-3.5 border-b border-border/50">
            <h3 className="text-sm sm:text-base font-bold text-foreground flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-primary" />
              Component Specifications ({requirementsList.length})
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onEditStep(2)}
              className="h-7 text-xs text-primary hover:text-primary hover:bg-primary/10 rounded-full gap-1 font-semibold px-3"
            >
              <Edit2 className="w-3 h-3" />
              Edit
            </Button>
          </div>

          {requirementsList.length === 0 ? (
            <p className="text-xs text-muted-foreground py-2">No component selections required.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {requirementsList.map((req) => (
                <div
                  key={req.parameterId}
                  className="p-3.5 rounded-[20px] bg-muted/20 border border-border/60 flex items-start gap-2.5"
                >
                  <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3 h-3" />
                  </div>
                  <div>
                    <span className="text-[11px] font-semibold text-muted-foreground block">
                      {req.parameterName}
                    </span>
                    <h5 className="text-xs sm:text-sm font-bold text-foreground mt-0.5">
                      {req.productName}
                    </h5>
                    {req.productDescription && (
                      <p className="text-[11px] text-muted-foreground line-clamp-1 mt-0.5">
                        {req.productDescription}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Submission CTA */}
      <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 bg-muted/30 p-5 rounded-[28px] border border-border/70">
        <div>
          <h4 className="text-sm sm:text-base font-bold text-foreground">Ready to receive your estimate?</h4>
        </div>

        <Button
          onClick={onSubmitQuotation}
          disabled={isSubmitting}
          className="btn-hero rounded-full w-full sm:w-auto px-7 py-3 text-sm font-bold flex items-center justify-center gap-2 shadow-lg shadow-primary/20 shrink-0"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Generating Quote...
            </>
          ) : (
            <>
              Submit Quotation Request
              <Send className="w-4 h-4 ml-1" />
            </>
          )}
        </Button>
      </div>
    </div>
  );
};
