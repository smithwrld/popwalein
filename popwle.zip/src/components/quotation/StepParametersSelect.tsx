import React from 'react';
import { ServiceParameter, ParameterProduct } from '@/lib/quotationApi';
import { cn } from '@/lib/utils';
import { CheckCircle2, SlidersHorizontal, AlertCircle, Package } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

interface StepParametersSelectProps {
  parameters: ServiceParameter[];
  selectedProducts: Record<string, string>; // parameterId -> productId
  onSelectProduct: (parameter: ServiceParameter, product: ParameterProduct) => void;
  isLoading?: boolean;
}

export const StepParametersSelect: React.FC<StepParametersSelectProps> = ({
  parameters,
  selectedProducts,
  onSelectProduct,
  isLoading = false,
}) => {
  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="text-left mb-4">
          <Skeleton className="h-7 w-56 mb-2 rounded-lg" />
          <Skeleton className="h-4 w-80 rounded-lg" />
        </div>
        {[1, 2, 3].map((paramIdx) => (
          <div key={paramIdx} className="p-5 border rounded-[28px] bg-card space-y-4">
            <Skeleton className="h-6 w-48 rounded-full" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {[1, 2, 3, 4].map((pIdx) => (
                <Skeleton key={pIdx} className="h-20 rounded-[20px]" />
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (parameters.length === 0) {
    return (
      <div className="text-center py-10 px-4 bg-muted/40 rounded-[28px] border border-dashed border-border">
        <SlidersHorizontal className="w-10 h-10 mx-auto text-muted-foreground mb-2 opacity-60" />
        <h3 className="text-base font-bold text-foreground">Standard Specifications Included</h3>
        <p className="text-xs text-muted-foreground mt-1">
          No customizable sub-parameters are required for this option. You can proceed to the review step.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-up">
      <div className="text-left mb-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-foreground">
          Select Your Specifications
        </h2>
        <p className="text-xs sm:text-sm text-muted-foreground mt-1">
          Customize each component by picking exactly one product per parameter below.
        </p>
      </div>

      <div className="space-y-6">
        {parameters.map((parameter, paramIndex) => {
          const selectedProductId = selectedProducts[parameter.id];
          const hasSelection = Boolean(selectedProductId);
          const products = parameter.products || [];

          return (
            <div
              key={parameter.id}
              className={cn(
                'rounded-[28px] p-4 sm:p-6 border-2 transition-all duration-300 bg-card shadow-sm',
                hasSelection
                  ? 'border-border/80 bg-card'
                  : parameter.is_required
                  ? 'border-primary/30 bg-primary/[0.01]'
                  : 'border-border/60'
              )}
            >
              {/* Parameter Header (Parent) */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 mb-4 border-b border-border/50">
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      'w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs shrink-0 transition-colors',
                      hasSelection
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground border border-border'
                    )}
                  >
                    {hasSelection ? <CheckCircle2 className="w-3.5 h-3.5 stroke-[2.5]" /> : paramIndex + 1}
                  </div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-base sm:text-lg font-bold text-foreground">
                        {parameter.name}
                      </h3>
                      {parameter.is_required ? (
                        <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-[11px] font-semibold py-0.5 rounded-full">
                          Required
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-[11px] font-medium py-0.5 rounded-full">
                          Optional
                        </Badge>
                      )}
                    </div>
                    {parameter.description && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {parameter.description}
                      </p>
                    )}
                  </div>
                </div>

                {/* Status Pill */}
                <div className="self-start sm:self-auto shrink-0">
                  {hasSelection ? (
                    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-primary bg-primary/10 px-3 py-1 rounded-full">
                      <CheckCircle2 className="w-3 h-3" />
                      Option Selected
                    </span>
                  ) : parameter.is_required ? (
                    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 bg-amber-500/10 px-3 py-1 rounded-full">
                      <AlertCircle className="w-3 h-3" />
                      Choice Needed
                    </span>
                  ) : null}
                </div>
              </div>

              {/* Products List inside Parameter (Grid of 2 Child Cards) */}
              {products.length === 0 ? (
                <div className="text-center py-5 px-4 bg-muted/20 rounded-[20px] border border-dashed text-xs text-muted-foreground">
                  <Package className="w-5 h-5 mx-auto mb-1 opacity-50" />
                  No specific products configured for {parameter.name}.
                </div>
              ) : (
                <div
                  role="radiogroup"
                  aria-label={`Select ${parameter.name}`}
                  className="grid grid-cols-1 sm:grid-cols-2 gap-3.5"
                >
                  {products.map((product) => {
                    const isSelected = selectedProductId === product.id;

                    return (
                       <div
                        key={product.id}
                        role="radio"
                        aria-checked={isSelected}
                        tabIndex={0}
                        onClick={() => onSelectProduct(parameter, product)}
                        onKeyDown={(e) => {
                          if (e.key === ' ' || e.key === 'Enter') {
                            e.preventDefault();
                            onSelectProduct(parameter, product);
                          }
                        }}
                        className={cn(
                          'group relative flex flex-col justify-between cursor-pointer rounded-[20px] p-3.5 transition-all duration-200 border-2 select-none active:scale-[0.99]',
                          isSelected
                            ? 'bg-primary/[0.04] border-primary ring-2 ring-primary/20 shadow-sm'
                            : 'bg-background hover:bg-muted/30 border-border/70 hover:border-primary/40'
                        )}
                      >
                        <div>
                          {/* Product Image Container */}
                          {product.image && (
                            <div className="relative w-full h-28 sm:h-32 rounded-[14px] overflow-hidden mb-2.5 bg-muted/40 flex items-center justify-center">
                              <img
                                src={product.image}
                                alt={product.name}
                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                loading="lazy"
                                onError={(e) => {
                                  (e.target as HTMLImageElement).style.display = 'none';
                                }}
                              />
                            </div>
                          )}

                          <div className="flex items-start justify-between gap-2.5 mb-1.5">
                            <h4
                              className={cn(
                                'text-xs sm:text-sm font-bold leading-snug transition-colors',
                                isSelected ? 'text-primary' : 'text-foreground group-hover:text-primary'
                              )}
                            >
                              {product.name}
                            </h4>

                            {/* Radio Circle Indicator */}
                            <div
                              className={cn(
                                'w-4 h-4 rounded-full border-2 flex items-center justify-center shrink-0 transition-all mt-0.5',
                                isSelected
                                  ? 'border-primary bg-primary text-primary-foreground'
                                  : 'border-border group-hover:border-primary/60 bg-card'
                              )}
                            >
                              {isSelected ? (
                                <div className="w-1.5 h-1.5 rounded-full bg-white" />
                              ) : null}
                            </div>
                          </div>

                          {product.title && product.title !== product.name && (
                            <p className="text-xs font-medium text-foreground/80 mb-1">
                              {product.title}
                            </p>
                          )}

                          {product.description && (
                            <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed mt-0.5">
                              {product.description}
                            </p>
                          )}
                        </div>

                        <div className="mt-2.5 pt-2 border-t border-border/40 flex items-center justify-between text-[11px]">
                          <span
                            className={cn(
                              'font-semibold',
                              isSelected ? 'text-primary' : 'text-muted-foreground/80'
                            )}
                          >
                            {isSelected ? 'Selected' : 'Choose option'}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
